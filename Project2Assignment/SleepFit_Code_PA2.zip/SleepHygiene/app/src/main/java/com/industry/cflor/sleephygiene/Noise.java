package com.industry.cflor.sleephygiene;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Noise extends AppCompatActivity {


    private static Button thunder_button;
    private static Button ocean_button;

    MediaPlayer thunder;
    MediaPlayer ocean;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noise);

        thunder = MediaPlayer.create(this, R.raw.thunder);
        ocean = MediaPlayer.create(this,R.raw.ocean);

    }


    public void playthundermusic(View view) {

        if(thunder.isPlaying())
        {
            thunder.seekTo(0);
            thunder.pause();
        }
        else
        {
            thunder.setLooping(true);
            thunder.start();

        }


    }

    public void playoceanmusic(View view) {

        if(ocean.isPlaying())
        {

            ocean.seekTo(0);
            ocean.pause();

        }
        else
        {
            ocean.setLooping(true);
            ocean.start();

        }

    }
}
