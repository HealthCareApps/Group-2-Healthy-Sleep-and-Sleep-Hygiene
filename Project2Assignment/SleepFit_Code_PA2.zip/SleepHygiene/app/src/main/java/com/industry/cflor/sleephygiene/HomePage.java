package com.industry.cflor.sleephygiene;

import android.app.Fragment;
import android.content.Intent;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class HomePage extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.activity_home_page, container, false);


    }

    public class HomePageActivity extends AppCompatActivity{

        @Override
        public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
            super.onCreate(savedInstanceState, persistentState);

            Intent intent = getIntent();
            String message = intent.getStringExtra(LogIn.USERN_MESSAGE);

            TextView textView = new TextView(this);
            textView.setTextSize(40);
            textView.setText(message);
            LinearLayout layout = (LinearLayout) findViewById(R.id.homepage_greeting);
            layout.addView(textView);
        }
    }
}
