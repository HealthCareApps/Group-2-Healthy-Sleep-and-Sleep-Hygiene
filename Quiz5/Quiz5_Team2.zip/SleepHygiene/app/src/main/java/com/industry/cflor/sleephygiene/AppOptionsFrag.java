package com.industry.cflor.sleephygiene;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Cflor on 3/9/2016.
 */
public class AppOptionsFrag extends Fragment{

    protected String[] mainOptions;
    protected ArrayAdapter<String> arrayAdapter;
    protected ListView listView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //getting the layout into the fragment
        View view = inflater.inflate(R.layout.options_rows_list_view, container, false);

        //displaying the list
        listView = (ListView)view.findViewById(R.id.options_list_view);
        mainOptions = getResources().getStringArray(R.array.app_tab_main_options);
        arrayAdapter = new ArrayAdapter<String>(getActivity(), R.layout.options_rows_layout_format, R.id.singleRow_options_format, mainOptions);
        listView.setAdapter(arrayAdapter);

        return view;
    }
}
