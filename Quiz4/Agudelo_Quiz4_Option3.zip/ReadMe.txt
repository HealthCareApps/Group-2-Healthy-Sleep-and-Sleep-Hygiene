The things I changed were I added in the menu overflow the "tips" and "about" section.
The tips section will just be text on tips on how to sleep better. The about setion is created in 
a new activty and will show information about the group and the version number.