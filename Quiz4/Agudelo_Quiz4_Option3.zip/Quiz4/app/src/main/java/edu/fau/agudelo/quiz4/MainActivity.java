package edu.fau.agudelo.quiz4;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        RelativeLayout main_view = (RelativeLayout) findViewById(R.id.main_view);
        switch(item.getItemId())
        {
            case R.id.menu_tips:
                if(item.isChecked())
                    item.setChecked(false);
                else
                item.setChecked(true);
                TextView tips = (TextView) findViewById(R.id.tips_text);
                tips.setText("You selected the \"tips\" section ");

            return true;



            case R.id.menu_about:
                if(item.isChecked())
                    item.setChecked(false);
                else
                    item.setChecked(true);
                Intent intent = new Intent(this,AboutActivity.class);
                startActivity(intent);
                tips = (TextView) findViewById(R.id.tips_text);
                tips.setText("");

              //  TextView about = (TextView) findViewById(R.id.about_text);
              //  about.setText("This is a new activity containing \"About\" section");




                return true;




            default:
                return super.onOptionsItemSelected(item);




        }
    }
}
