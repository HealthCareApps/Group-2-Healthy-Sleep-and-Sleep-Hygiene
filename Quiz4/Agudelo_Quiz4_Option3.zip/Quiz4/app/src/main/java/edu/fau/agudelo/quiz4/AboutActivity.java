package edu.fau.agudelo.quiz4;

import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * Created by Santiago on 3/17/2016.
 */
public class AboutActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        LinearLayout about_view = (LinearLayout) findViewById(R.id.about_view);

        TextView about = (TextView) findViewById(R.id.about_text);
        about.setText("This is a new activity where the \"about\" details will be");

    }




}
