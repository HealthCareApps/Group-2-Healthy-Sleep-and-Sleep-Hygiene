package com.industry.cflor.sleephygiene;

import android.app.Activity;
import android.app.Fragment;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

/**
 * Created by Cflor on 4/28/2016.
 */
public class Sounds extends Activity {

    private final String clickOnListError = "Sorry, something went wrong";
    protected ListView musicList;
    protected ListView noiseList;

    protected String[] musicNames;
    protected ArrayAdapter<String> musicListAdapter;

    protected String[] noiseNames;
    protected ArrayAdapter<String> noiseListAdapter;

    protected MediaPlayer zen;
    protected MediaPlayer piano;
    protected MediaPlayer violin;
    protected MediaPlayer campfire;
    protected MediaPlayer night;
    protected MediaPlayer ocean;
    protected MediaPlayer thunder;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sounds);

        //Setting up the music
        zen = MediaPlayer.create(this, R.raw.zen);
        piano = MediaPlayer.create(this, R.raw.piano);
        violin = MediaPlayer.create(this, R.raw.violin);
        campfire = MediaPlayer.create(this, R.raw.campfire);
        thunder = MediaPlayer.create(this, R.raw.thunder);
        night = MediaPlayer.create(this, R.raw.night);
        ocean = MediaPlayer.create(this, R.raw.ocean);

        //music list set up
        musicList = (ListView) findViewById(R.id.music_listView);
        musicNames = getResources().getStringArray(R.array.musics_list);
        musicListAdapter = new ArrayAdapter<String>(this, R.layout.options_rows_layout_format, R.id.singleRow_options_format, musicNames);
        musicList.setAdapter(musicListAdapter);

        //noise list set up
        noiseList = (ListView) findViewById(R.id.noise_listView);
        noiseNames = getResources().getStringArray(R.array.noises_list);
        noiseListAdapter = new ArrayAdapter<String>(this, R.layout.options_rows_layout_format, R.id.singleRow_options_format,noiseNames);
        noiseList.setAdapter(noiseListAdapter);


        customSoundListener(musicList,noiseList);

    }

    public void customSoundListener(ListView musicList, ListView noiseList){
        this.musicList = musicList;
        this.noiseList = noiseList;


        musicList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){

                    case 0:
                        getMusic(position);
                        break;
                    case 1:
                        getMusic(position);
                        break;
                    case 2:
                        getMusic(position);
                        break;

                    default:
                        Toast.makeText(getApplicationContext(),clickOnListError, Toast.LENGTH_LONG).show();

                }
            }
        });

        noiseList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch(position){

                    case 0:
                        getNoise(position);
                        break;
                    case 1:
                        getNoise(position);
                        break;
                    case 2:
                        getNoise(position);
                        break;
                    case 3:
                        getNoise(position);
                        break;

                    default:
                        Toast.makeText(getApplicationContext(),clickOnListError, Toast.LENGTH_LONG).show();

                }
            }
        });

    }

    public void getMusic(int pCase){
        if(pCase == 0){
            if(zen.isPlaying()){
                zen.seekTo(0);
                zen.pause();
            } else{
                zen.setLooping(true);
                zen.start();
            }
        }
        else if(pCase == 1){
            if(piano.isPlaying()){
                piano.seekTo(0);
                piano.pause();
            } else{
                piano.setLooping(true);
                piano.start();
            }

        }else if(pCase == 2){

            if(violin.isPlaying()){
                violin.seekTo(0);
                violin.pause();
            } else{
                violin.setLooping(true);
                violin.start();
            }
        }
    }

    public void getNoise(int pCase){
        if(pCase == 0){
            if(campfire.isPlaying()){
                campfire.seekTo(0);
                campfire.pause();
            } else{
                campfire.setLooping(true);
                campfire.start();
            }
        }
        else if(pCase == 1){
            if(ocean.isPlaying()){
                ocean.seekTo(0);
                ocean.pause();
            } else{
                ocean.setLooping(true);
                ocean.start();
            }

        }else if(pCase == 2){

            if(thunder.isPlaying()){
                thunder.seekTo(0);
                thunder.pause();
            } else{
                thunder.setLooping(true);
                thunder.start();
            }
        }else if(pCase == 3){

            if(night.isPlaying()){
                night.seekTo(0);
                night.pause();
            } else{
                night.setLooping(true);
                night.start();
            }
        }


    }

    @Override
    protected void onStart() {
        super.onStart();

        Toast.makeText(getApplicationContext(),"Select a sound item from the categories.",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        zen.release();
        piano.release();
        violin.release();
        ocean.release();
        campfire.release();
        thunder.release();
        night.release();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

}


