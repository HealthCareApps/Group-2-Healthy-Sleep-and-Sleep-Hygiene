package com.industry.cflor.sleephygiene;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LogIn extends AppCompatActivity {

    public final static String USERN_MESSAGE = "com.industry.cflor.sleephygiene.MESSAGE";

    private final String[] correct_Username = {"Charles","Santiago","Bob","Ivan","Leslie"};
    private final String[] correct_Password = {"Florestal","Agudelo","Fennell","Kalytovskyy","Yanes"};
    final String error_Incorrect = "You have entered an incorrect username or password!";



    protected EditText username;
    protected EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        username = (EditText) findViewById(R.id.username_login);
        password = (EditText) findViewById(R.id.password_login);


        //username.clearFocus();
        //password.clearFocus();
    }

    public void getRegistered(View view){
        Intent intent = new Intent(this,Registration.class);
        startActivity(intent);
    }

    public void getMainPage(View view){
        Intent intent = new Intent(this, Sleepfit.class);

        String mUsername = username.getText().toString().trim();
        String mPassword = password.getText().toString().trim();

        intent.putExtra(USERN_MESSAGE, mUsername);

        if((mUsername.equals(correct_Username[0]))&&(mPassword.equals(correct_Password[0]))){
            startActivity(intent);
        }else if((mUsername.equals(correct_Username[1]))&&(mPassword.equals(correct_Password[1]))){
            startActivity(intent);
        }else if((mUsername.equals(correct_Username[2]))&&(mPassword.equals(correct_Password[2]))){
            startActivity(intent);
        }else if((mUsername.equals(correct_Username[3]))&&(mPassword.equals(correct_Password[3]))){
            startActivity(intent);
        }else if((mUsername.equals(correct_Username[4]))&&(mPassword.equals(correct_Password[4]))){
            startActivity(intent);
        }else{
            Toast.makeText(getApplicationContext(),error_Incorrect,Toast.LENGTH_LONG).show();
        }
    }


    public void logInWithDatabase(View view){
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);

        Patients patients_Name =
                dbHandler.findPatients(username.getText().toString().trim());
        Patients patients_Password =
                dbHandler.findPatients(password.getText().toString().trim());

        if ((patients_Name != null)&&(patients_Password != null)) {
            Intent intent = new Intent(this, Sleepfit.class);
            intent.putExtra(USERN_MESSAGE, username.getText().toString().trim());
            startActivity(intent);

        } else {
            Toast.makeText(getApplicationContext(),error_Incorrect,Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        editTextPref();
        Toast.makeText(getApplicationContext(), "If you have not register, click the blue register link", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();

        editTextPref();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    public void editTextPref(){


        username.setFocusable(false);
        username.setFocusableInTouchMode(false);
        password.setFocusable(false);
        password.setFocusableInTouchMode(false);

        username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username.setFocusable(true);
                username.setFocusableInTouchMode(true);
            }
        });

        password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                password.setFocusable(true);
                password.setFocusableInTouchMode(true);
            }
        });
    }
}
