package com.industry.cflor.sleephygiene;


import android.app.Fragment;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.LineData;

/**
 * Created by Cflor on 3/26/2016.
 */
public class Data extends Fragment {

    private LinearLayout graphLayout;
    private LineChart mChart;
    private Button senseApp_Button;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_data, container, false);

        return view;

    }

/*
    public void makeGraph(View view){
        graphLayout = (LinearLayout)view.findViewById(R.id.data_body_content);

        //creating linechart
        mChart = new LineChart(getActivity());

        //add to main layout
        graphLayout.addView(mChart, 700, 500);

        //


        //customizing line chart

        mChart.setDescription("");
        mChart.setNoDataTextDescription("No Data for the moment");

        //enable gestures
        mChart.setTouchEnabled(true);

        //enabling scaling and dragging
        mChart.setDragEnabled(true);
        mChart.setScaleEnabled(true);
        mChart.setDrawGridBackground(false);

        //enable pinch zoom to scaling x and y axis separately
        mChart.setPinchZoom(true);

        //alternating background color
        mChart.setBackgroundColor(Color.LTGRAY);

        //now the data
        LineData data = new LineData();
        data.setValueTextColor(Color.WHITE);

        //add data to line chart
        mChart.setData(data);

        //get legends object
        Legend legend = mChart.getLegend();

        //customize legend
        legend.setForm(Legend.LegendForm.LINE);
        legend.setTextColor(Color.WHITE);

        XAxis xl= mChart.getXAxis();
        xl.setTextColor(Color.WHITE);
        xl.setDrawGridLines(false);
        xl.setAvoidFirstLastClipping(true);

        YAxis yl = mChart.getAxisLeft();
        yl.setTextColor(Color.WHITE);
        yl.setAxisMaxValue(120f);
        yl.setDrawGridLines(true);


        YAxis yl2= mChart.getAxisRight();
        yl2.setEnabled(false);

    }
*/

    @Override
    public void onStart() {
        super.onStart();

    }

    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void onStop() {
        super.onStop();
    }
}
