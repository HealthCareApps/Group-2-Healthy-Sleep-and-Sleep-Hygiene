package com.industry.cflor.sleephygiene;



import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class Sleepfit extends ActionBarActivity {


    protected FragmentTransaction fragmentTransaction;
    protected FragmentManager fragmentManager;

    private HomePage homePage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sleepfit);

        homePage = new HomePage();
        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.frag_container, homePage);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.app_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.id_menu_account:
                Toast.makeText(getApplicationContext(),"Haven't implement anything yet!",Toast.LENGTH_LONG).show();
                return true;
            case R.id.id_menu_share:
                Toast.makeText(getApplicationContext(),"Haven't implement anything yet!",Toast.LENGTH_LONG).show();
                return true;
            case R.id.id_menu_about:
                Toast.makeText(getApplicationContext(),"Try sign out, -_-",Toast.LENGTH_LONG).show();
                return true;
            case R.id.id_menu_settings:
                Toast.makeText(getApplicationContext(),"Haven't implement anything yet!",Toast.LENGTH_LONG).show();
                return true;
            case R.id.id_menu_signOut:
                Intent intent = new Intent(this, LogIn.class);
                startActivity(intent);
                return true;
            default:
                break;
        }

        return false;
    }

}
