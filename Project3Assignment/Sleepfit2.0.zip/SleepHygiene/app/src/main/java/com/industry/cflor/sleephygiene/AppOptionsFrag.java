package com.industry.cflor.sleephygiene;


import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;


/**
 * Created by Cflor on 3/9/2016.
 */
public class AppOptionsFrag extends Fragment {

    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;

    final String optionClickError = "I am not sure what happen, but invalid action.";
    private Data data;
    private SleepAids sleepAids;
    private Sleepfit sleepfit;
    private LogIn logIn;
    private Registration registration;


    protected ImageButton alarmButton;
    protected ImageButton sensorDataButton;
    protected ImageButton sleepAidsButton;
    protected ImageButton uploadDataButton;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.main_page_icons, container, false);

        data = new Data();
        sleepfit = new Sleepfit();
        sleepAids = new SleepAids();
        logIn = new LogIn();
        registration = new Registration();

        //initializing the fragment methods
        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();


        //pointing current fragment methods to main activity fragment methods
        sleepfit.fragmentManager = fragmentManager;
        sleepfit.fragmentTransaction = fragmentTransaction;

        mainButtons(view);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //mainButtons();


    }

    public void mainButtons(View view){

        //initializing the button
        alarmButton = (ImageButton) view.findViewById(R.id.alarm_icon);
        sensorDataButton = (ImageButton) view.findViewById(R.id.sensor_data_icon);
        sleepAidsButton = (ImageButton) view.findViewById(R.id.sleep_aids_icon);
        uploadDataButton = (ImageButton) view.findViewById(R.id.upload_data_icon);



        alarmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity().getApplicationContext(),"No Functionality",Toast.LENGTH_LONG).show();
            }
        });

        sensorDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentTransaction.replace(R.id.frag_container, data);
                fragmentTransaction.commitAllowingStateLoss();
            }
        });

        sleepAidsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentTransaction.replace(R.id.frag_container, sleepAids);
                fragmentTransaction.commitAllowingStateLoss();
            }
        });

        uploadDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent launchSenseApp = getActivity().getPackageManager().getLaunchIntentForPackage("is.hello.sense");
                startActivity(launchSenseApp);
            }
        });

    }


}
