package com.industry.cflor.sleephygiene;

/**
 * Created by Cflor on 4/29/2016.
 */
public class Patients {

    private String email;
    private String patientsName;
    private String patientsPassword;

    public Patients() {

    }

    public Patients(String email, String patientName, String patientsPassword) {
        this.email = email;
        this.patientsName = patientName;
        this.patientsPassword = patientsPassword;
    }

    public Patients(String patientsName, String patientsPassword) {
        this.patientsName = patientsName;
        this.patientsPassword = patientsPassword;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return this.email;
    }

    public void setPatientsName(String patientsName) {
        this.patientsName = patientsName;
    }

    public String getPatientsName() {
        return this.patientsName;
    }

    public void setPatientsPassword(String patientsPassword) {
        this.patientsPassword = patientsPassword;
    }

    public String getPatientsPassword() {
        return this.patientsPassword;
    }
}
