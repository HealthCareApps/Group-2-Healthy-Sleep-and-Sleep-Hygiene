package com.industry.cflor.sleephygiene;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Cflor on 4/29/2016.
 */
public class MyDBHandler extends SQLiteOpenHelper {

    private ContentResolver myCR;

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "patientsDB.db";
    public static final String TABLE_PRODUCTS = "patients";

    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_PATIENTSNAME = "patientsName";
    public static final String COLUMN_PATIENTSPASSWORD = "patientsPassword";

    public MyDBHandler(Context context, String name,
                       SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
        myCR = context.getContentResolver();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_PRODUCTS_TABLE = "CREATE TABLE " +
                TABLE_PRODUCTS + "("
                + COLUMN_EMAIL + " STRING PRIMARY KEY," + COLUMN_PATIENTSNAME
                + " TEXT," + COLUMN_PATIENTSPASSWORD + " TEXT" + ")";
        db.execSQL(CREATE_PRODUCTS_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCTS);
        onCreate(db);

    }

    public void addPatients(Patients patients) {

        ContentValues values = new ContentValues();
        values.put(COLUMN_PATIENTSNAME, patients.getPatientsName());
        values.put(COLUMN_PATIENTSPASSWORD, patients.getPatientsPassword());

        myCR.insert(MyContentProvider.CONTENT_URI, values);
    }

    public Patients findPatients(String patientsName) {
        String[] projection = {COLUMN_EMAIL,
                COLUMN_PATIENTSNAME, COLUMN_PATIENTSPASSWORD };

        String selection = "patientsName = \"" + patientsName + "\"";

        Cursor cursor = myCR.query(MyContentProvider.CONTENT_URI,
                projection, selection, null,
                null);

        Patients patients = new Patients();

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            patients.setEmail(cursor.getString(0));
            patients.setPatientsName(cursor.getString(1));
            patients.setPatientsPassword(cursor.getString(2));
            cursor.close();
        } else {
            patients = null;
        }
        return patients;
    }

    public boolean deleteProduct(String patientsName) {

        boolean result = false;

        String selection = "productsName = \"" + patientsName + "\"";

        int rowsDeleted = myCR.delete(MyContentProvider.CONTENT_URI,
                selection, null);

        if (rowsDeleted > 0)
            result = true;

        return result;

    }

}