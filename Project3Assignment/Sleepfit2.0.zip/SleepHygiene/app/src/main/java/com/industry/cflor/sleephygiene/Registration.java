package com.industry.cflor.sleephygiene;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    protected EditText RUsername;
    protected EditText RPassword;
    protected EditText firstName;
    protected EditText lastName;
    protected EditText email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        //initializing the different EditText info.
        RUsername = (EditText) findViewById(R.id.username_editText);
        RPassword = (EditText) findViewById(R.id.password_editText);
        firstName = (EditText) findViewById(R.id.first_name_editText);
        lastName = (EditText) findViewById(R.id.last_name_editText);
        email = (EditText) findViewById(R.id.email_editText);
    }

    public void createAccount(View view){

        //taking all the inputs and converting into string
        RUsername.getText().toString().trim();
        RPassword.getText().toString().trim();
        firstName.getText().toString().trim();
        lastName.getText().toString().trim();
        email.getText().toString().trim();

       //add crendentials to database
            /*
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);

        String patientsPassword = RPassword.getText().toString().trim();

        Patients product =
                new Patients(RUsername.getText().toString(), patientsPassword);

        dbHandler.addPatients(product);
        RUsername.setText("");
        RPassword.setText("");
        */

        Toast.makeText(getApplicationContext(),"You have successfully created an account",Toast.LENGTH_LONG).show();
    }

}
