package com.industry.cflor.sleephygiene;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;

/**
 * Created by Cflor on 3/26/2016.
 */
public class Tip extends Fragment {


}
