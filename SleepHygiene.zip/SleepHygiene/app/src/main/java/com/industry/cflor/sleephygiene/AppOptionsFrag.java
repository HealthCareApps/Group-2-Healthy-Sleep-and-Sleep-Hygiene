package com.industry.cflor.sleephygiene;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.annotation.Nullable;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by Cflor on 3/9/2016.
 */
public class AppOptionsFrag extends Fragment {

    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;

    final String optionClickError = "I am not sure what happen, but invalid action.";
    private Data data;
    private HomePage homePage;
    private Healthcare healthcare;
    private Extras extras;
    private Tip tip;
    private Preference preference;
    private Sleepfit sleepfit;

    OnOptionsSelectedListener mCallback;

    public interface OnOptionsSelectedListener{

        public void onOptionsSelected(int position);
    }

    protected String[] mainOptions;
    protected ArrayAdapter<String> arrayAdapter;
    protected ListView listView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //getting the layout into the fragment
        View view = inflater.inflate(R.layout.options_rows_list_view, container, false);

        //displaying the list
        listView = (ListView)view.findViewById(R.id.options_list_view);
        mainOptions = getResources().getStringArray(R.array.app_tab_main_options);
        arrayAdapter = new ArrayAdapter<String>(getActivity(), R.layout.options_rows_layout_format, R.id.singleRow_options_format, mainOptions);
        listView.setAdapter(arrayAdapter);


        //initializing the called classes
        data = new Data();
        homePage = new HomePage();
        healthcare = new Healthcare();
        extras = new Extras();
        preference = new Preference();
        tip = new Tip();
        sleepfit = new Sleepfit();


        customListViewListener(listView);



        return view;
    }


    public void customListViewListener(ListView listView){
        this.listView = listView;


        //creating action on option click
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //Toast.makeText(getContext(),parent.getItemIdAtPosition(position) + " is selected",Toast.LENGTH_LONG).show();

                //initializing the fragment methods
                fragmentManager = getFragmentManager();
                fragmentTransaction = fragmentManager.beginTransaction();

                //pointing current fragment methods to main activity fragment methods
                sleepfit.fragmentManager = fragmentManager;
                sleepfit.fragmentTransaction = fragmentTransaction;

                switch (position) {
                    case 0:
                        fragmentTransaction.replace(R.id.frag_container, homePage);
                        break;
                    case 1:
                        fragmentTransaction.replace(R.id.frag_container, healthcare);
                        break;
                    case 2:
                        fragmentTransaction.replace(R.id.frag_container, data);
                        break;
                    case 3:
                        fragmentTransaction.replace(R.id.frag_container, extras);
                        break;
                    case 4:
                        fragmentTransaction.replace(R.id.frag_container, tip);
                        break;
                    case 5:
                        fragmentTransaction.replace(R.id.frag_container, preference);
                        break;
                    default:
                        Toast.makeText(getActivity(), optionClickError, Toast.LENGTH_LONG).show();
                        break;
                }

                fragmentTransaction.commit();
            }
        });

    }


}
